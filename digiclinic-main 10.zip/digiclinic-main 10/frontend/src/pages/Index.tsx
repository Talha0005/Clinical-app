import { DigiClinic } from "@/components/DigiClinic";

const Index = () => {
  return <DigiClinic />;
};

export default Index;

"""DigiCare MCP Server - A medical systems MCP server for experimental healthcare AI research."""

__version__ = "0.1.0"
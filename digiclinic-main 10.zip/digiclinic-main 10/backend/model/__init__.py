"""Model package for DigiClinic."""

from .patient import Patient

__all__ = ["Patient"]